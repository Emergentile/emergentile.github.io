#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
for arch in amd64 arm64; do
    for format in iso img; do
        "$PROJECT_DIR/image-build/build.sh" --arch "$arch" --format "$format"
    done
done
