const commands = `tar -xzf emergentilegui-1-source.tar.gz
cd Emergentile
sudo make install-system`;

document.querySelector('#copyCommand').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(commands);
    const toast = document.querySelector('#toast');
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1800);
  } catch (_) {
    window.prompt('Copy these commands:', commands);
  }
});

// Disable artifact links cleanly until the packaging script has placed files.
document.querySelectorAll('.artifact-link').forEach(async link => {
  try {
    const response = await fetch(link.getAttribute('href'), { method: 'HEAD' });
    if (!response.ok) link.classList.add('unavailable');
  } catch (_) {
    // file:// previews cannot perform HEAD requests; preserve links there.
  }
});
