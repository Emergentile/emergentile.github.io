# Emergentile website

Preview locally from the project root:

```bash
make website-preview
```

Prepare the downloadable source archive and copy built ISO/IMG artifacts:

```bash
make website-downloads
```

Then deploy the contents of `website/` to any static host. Links for images that
have not been built yet are marked as unavailable when served over HTTP.
